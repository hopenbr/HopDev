param([string]$DestWebURL = $(throw 'The full url of new list is required'), 
      [string]$FileName = $(throw 'The full UNC path to the DAT file is required'), 
      [string]$LogFilePath = $("C:\SPListImport.log"))



[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint") > $null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Deployment") > $null

$settings = New-Object Microsoft.SharePoint.Deployment.SPImportSettings

$settings.IncludeSecurity = [Microsoft.SharePoint.Deployment.SPIncludeSecurity]::All
$settings.UpdateVersions = [Microsoft.SharePoint.Deployment.SPUpdateVersions]::Overwrite 
$settings.UserInfoDateTime = [Microsoft.SharePoint.Deployment.SPImportUserInfoDateTimeOption]::ImportAll

$site = new-object Microsoft.SharePoint.SPSite($DestWebURL)

Write-Host "DestWebURL", $DestWebURL

$web = $site.OpenWeb()

Write-Host "SPWeb", $web.Url

$settings.SiteUrl = $web.Url
$settings.WebUrl = $web.Url
$settings.FileLocation = "C:\Temp\BackupRestoreTemp\"
$settings.BaseFileName = $FileName
$settings.LogFilePath = $LogFilePath
$settings.FileCompression = 1

Write-Host "FileLocation", $settings.FileLocation

$import = New-Object Microsoft.SharePoint.Deployment.SPImport($settings)
$import.Run()

$web.Dispose()
$site.Dispose()
