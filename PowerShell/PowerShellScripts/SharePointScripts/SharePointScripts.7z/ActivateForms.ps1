.\stsadm.exe -o enumformtemplates | ?{$_ -match "2008-"} | %{$_.Split("`t")[1]} | %{.\stsadm.exe -o activateformtemplate -url "Http://as73mosstst02:24921/sites/Carrier" -formid $_  }

.\stsadm.exe -o enumformtemplates | ?{$_ -match "2008-"} | %{$_.Split("`t")[1]} | %{.\stsadm.exe -o activateformtemplate -url "Http://as73mosstst02:24921/sites/Employer" -formid $_  }

.\stsadm.exe -o enumformtemplates | ?{$_ -match "2008-"} | %{$_.Split("`t")[1]} | %{.\stsadm.exe -o activateformtemplate -url "Http://as73mosstst02:24921/sites/Agent" -formid $_  }