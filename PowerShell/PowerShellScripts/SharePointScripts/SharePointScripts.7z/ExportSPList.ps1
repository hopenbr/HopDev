param([string] $ListUrl = $(throw 'Full Url to list to export is required'),
      [string] $path2DatFile = $("C:\Temp\BackupRestoreTemp\"))




[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint") > $null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Deployment") > $null

$versions = [Microsoft.SharePoint.Deployment.SPIncludeVersions]::All

$exportObject = New-Object Microsoft.SharePoint.Deployment.SPExportObject
$exportObject.Type = [Microsoft.SharePoint.Deployment.SPDeploymentObjectType]::List 
$exportObject.IncludeDescendants = [Microsoft.SharePoint.Deployment.SPIncludeDescendants]::All

$settings = New-Object Microsoft.SharePoint.Deployment.SPExportSettings

	
$settings.ExportMethod = [Microsoft.SharePoint.Deployment.SPExportMethodType]::ExportAll
$settings.IncludeVersions = $versions
$settings.IncludeSecurity = [Microsoft.SharePoint.Deployment.SPIncludeSecurity]::All
$settings.OverwriteExistingDataFile = 1

$site = new-object Microsoft.SharePoint.SPSite($ListURL)
Write-Host "ListURL", $ListURL

$web = $site.OpenWeb()
$list = $web.GetList($ListURL)

[string] $fileName = "ExportList-"+ $list.ID.ToString()

$settings.SiteUrl = $web.Url
$exportObject.Id = $list.ID
$settings.FileLocation = $path2DatFile
$settings.BaseFileName = $fileName  +".DAT"
$settings.FileCompression = 1

Write-Host "FileLocation", $settings.FileLocation

$settings.ExportObjects.Add($exportObject)

$export = New-Object Microsoft.SharePoint.Deployment.SPExport($settings)
$export.Run()

$ListUrl | out-file -filePath $(Join-Path $path2DatFile $($fileName + ".url")) -encoding ASCII

$web.Dispose()
$site.Dispose()

