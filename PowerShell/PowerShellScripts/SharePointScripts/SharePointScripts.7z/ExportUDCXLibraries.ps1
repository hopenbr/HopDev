param([string] $url = $(throw 'The full url to the site is required'),
      [string] $datFolder = $("C:\SPExports\" + $(Get-Date).ToString('yyyyMMdd')))

function get-script
{
   if($myInvocation.ScriptName) { $myInvocation.ScriptName }
   else { $myInvocation.MyCommand.Definition }
}




###MAIN###

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint") > $null

if ($HelperFunctions -ne 1)
{
	pushd $(split-path $(get-script) -parent)
	.\Helper.Functions.ps1
	popd
}


pushd $(Split-Path $(get-script) -Parent)


$site = new-object Microsoft.SharePoint.SPSite($URL)

$web = $site.OpenWeb()

$web.lists | 
	?{$_.title -match "UDCX" } | 
		%{ 
			[string] $udcxUrl = $($web.Url + "/" +  $_.rootfolder)

			wh "Exporting $udcxUrl" 
			
			.\exportSPList.ps1 $udcxUrl $datFolder 
			
			wh "export Complete"

		 }


$web.Dispose()

$site.Dispose()

popd